import com.oracle.bmc.ConfigFileReader;
import com.oracle.bmc.ConfigFileReader.ConfigFile;
import com.oracle.bmc.auth.ConfigFileAuthenticationDetailsProvider;
import com.oracle.bmc.model.BmcException;
import com.oracle.bmc.objectstorage.ObjectStorageClient;
import com.oracle.bmc.objectstorage.model.ListObjects;
import com.oracle.bmc.objectstorage.model.ObjectSummary;
import com.oracle.bmc.objectstorage.requests.GetNamespaceRequest;
import com.oracle.bmc.objectstorage.requests.GetObjectRequest;
import com.oracle.bmc.objectstorage.requests.ListObjectsRequest;
import com.oracle.bmc.objectstorage.requests.PutObjectRequest;
import com.oracle.bmc.objectstorage.responses.GetNamespaceResponse;
import com.oracle.bmc.objectstorage.responses.GetObjectResponse;
import com.oracle.bmc.objectstorage.responses.ListObjectsResponse;
import com.oracle.bmc.objectstorage.responses.PutObjectResponse;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Single-class Java 17 command-line and HTTP application for OCI Object Storage operations.
 *
 * <p>The application deliberately keeps credentials, OCIDs, namespace, region, and local file
 * paths out of source code. Authentication details are loaded from the standard OCI config file,
 * and local paths/object names are supplied at runtime.
 */
public class ObjectStorageApplication {
    private static final String HTTP_HOST = "127.0.0.1";
    private static final int HTTP_PORT = 8080;
    private static final String OCI_PROFILE = "DEFAULT";
    private static final String BUCKET_NAME = "litedesk-oci-bucket";
    private static final String OBJECT_LIST_FIELDS = "name,size,etag";

    /**
     * Starts HTTP mode when no arguments are provided, or runs the original CLI sequence when
     * upload/download path arguments are supplied.
     */
    public static void main(String[] args) {
        if (args.length == 0) {
            try {
                startHttpServer();
            } catch (IOException e) {
                System.err.println("Failed to start HTTP server: " + e.getMessage());
                System.exit(1);
            }
            return;
        }

        runCommandLineSequence(args);
    }

    /**
     * Demonstrates the requested CLI operation sequence: list, upload, list again, download,
     * success.
     */
    private static void runCommandLineSequence(String[] args) {
        if (args.length < 2 || args.length > 4) {
            printUsage();
            System.exit(1);
        }

        ObjectStorageClient client = null;
        boolean failed = false;

        try {
            Path uploadFilePath = validateUploadFilePath(args[0]);
            Path downloadFilePath = Paths.get(args[1]).toAbsolutePath().normalize();
            String uploadObjectName = args.length >= 3 ? validateObjectName(args[2]) : uploadFilePath.getFileName().toString();
            String downloadObjectName = args.length >= 4 ? validateObjectName(args[3]) : uploadObjectName;

            System.out.println("Starting OCI Object Storage application.");
            System.out.println("Bucket: " + BUCKET_NAME);
            System.out.println("Upload file: " + uploadFilePath);
            System.out.println("Upload object name: " + uploadObjectName);
            System.out.println("Download object name: " + downloadObjectName);
            System.out.println("Download file: " + downloadFilePath);

            client = createObjectStorageClient();
            String namespaceName = getObjectStorageNamespace(client);

            listAllObjects(client, namespaceName);
            uploadFile(client, namespaceName, uploadFilePath, uploadObjectName);
            listAllObjects(client, namespaceName);
            downloadObject(client, namespaceName, downloadObjectName, downloadFilePath);

            System.out.println("All OCI Object Storage operations completed successfully.");
        } catch (IllegalArgumentException e) {
            failed = true;
            System.err.println("Invalid input: " + e.getMessage());
            printUsage();
        } catch (BmcException e) {
            failed = true;
            System.err.println("OCI request failed.");
            System.err.println("Status code: " + e.getStatusCode());
            System.err.println("Service code: " + e.getServiceCode());
            System.err.println("OPC request ID: " + e.getOpcRequestId());
            System.err.println("Message: " + e.getMessage());
        } catch (IOException e) {
            failed = true;
            System.err.println("Local file or OCI configuration error: " + e.getMessage());
        } catch (RuntimeException e) {
            failed = true;
            System.err.println("Unexpected error: " + e.getMessage());
            e.printStackTrace(System.err);
        } finally {
            if (client != null) {
                System.out.println("Closing OCI ObjectStorageClient.");
                client.close();
            }
        }

        if (failed) {
            System.exit(1);
        }
    }

    /**
     * Starts a small Java built-in HTTP server for Postman testing.
     */
    public static void startHttpServer() throws IOException {
        int httpPort = getHttpPort();
        HttpServer server = HttpServer.create(new InetSocketAddress(HTTP_HOST, httpPort), 0);

        server.createContext("/health", ObjectStorageApplication::handleHealthRequest);
        server.createContext("/objects", ObjectStorageApplication::handleListObjectsRequest);
        server.createContext("/upload", ObjectStorageApplication::handleUploadRequest);
        server.createContext("/download", ObjectStorageApplication::handleDownloadRequest);
        server.setExecutor(null);

        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            System.out.println("Stopping HTTP server.");
            server.stop(0);
        }));

        server.start();
        System.out.println("HTTP server started successfully.");
        System.out.println("Postman base URL: http://" + HTTP_HOST + ":" + httpPort);
        System.out.println("GET  http://" + HTTP_HOST + ":" + httpPort + "/health");
        System.out.println("GET  http://" + HTTP_HOST + ":" + httpPort + "/objects");
        System.out.println("POST http://" + HTTP_HOST + ":" + httpPort + "/upload?filePath=C%3A%5CTemp%5Coci-upload-test.txt&objectName=oci-upload-test.txt");
        System.out.println("GET  http://" + HTTP_HOST + ":" + httpPort + "/download?objectName=oci-upload-test.txt&downloadPath=C%3A%5CTemp%5Coci-download-test.txt");
    }

    private static int getHttpPort() {
        String configuredPort = System.getProperty("server.port", String.valueOf(HTTP_PORT));
        try {
            int parsedPort = Integer.parseInt(configuredPort);
            if (parsedPort < 1 || parsedPort > 65535) {
                throw new IllegalArgumentException("server.port must be between 1 and 65535: " + configuredPort);
            }
            return parsedPort;
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("server.port must be a valid integer: " + configuredPort, e);
        }
    }

    private static void handleHealthRequest(HttpExchange exchange) throws IOException {
        System.out.println("HTTP request: " + exchange.getRequestMethod() + " " + exchange.getRequestURI());
        if (!"GET".equalsIgnoreCase(exchange.getRequestMethod())) {
            sendMethodNotAllowed(exchange, "GET");
            return;
        }

        sendJsonResponse(exchange, 200, "{\"status\":\"UP\",\"bucket\":" + jsonString(BUCKET_NAME) + "}");
    }

    private static void handleListObjectsRequest(HttpExchange exchange) throws IOException {
        System.out.println("HTTP request: " + exchange.getRequestMethod() + " " + exchange.getRequestURI());
        if (!"GET".equalsIgnoreCase(exchange.getRequestMethod())) {
            sendMethodNotAllowed(exchange, "GET");
            return;
        }

        ObjectStorageClient client = null;
        try {
            client = createObjectStorageClient();
            String namespaceName = getObjectStorageNamespace(client);
            String responseJson = listAllObjects(client, namespaceName);
            sendJsonResponse(exchange, 200, responseJson);
        } catch (Exception e) {
            sendExceptionResponse(exchange, e);
        } finally {
            closeClient(client);
        }
    }

    private static void handleUploadRequest(HttpExchange exchange) throws IOException {
        System.out.println("HTTP request: " + exchange.getRequestMethod() + " " + exchange.getRequestURI());
        if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
            sendMethodNotAllowed(exchange, "POST");
            return;
        }

        ObjectStorageClient client = null;
        try {
            Map<String, String> queryParameters = parseQueryParameters(exchange.getRequestURI().getRawQuery());
            Path uploadFilePath = validateUploadFilePath(requiredQueryParameter(queryParameters, "filePath"));
            String objectName = queryParameters.get("objectName");
            if (objectName == null || objectName.isBlank()) {
                objectName = uploadFilePath.getFileName().toString();
            }
            objectName = validateObjectName(objectName);

            client = createObjectStorageClient();
            String namespaceName = getObjectStorageNamespace(client);
            PutObjectResponse uploadResponse = uploadFile(client, namespaceName, uploadFilePath, objectName);

            String responseJson = "{"
                    + "\"message\":\"Upload completed successfully\","
                    + "\"bucket\":" + jsonString(BUCKET_NAME) + ","
                    + "\"namespace\":" + jsonString(namespaceName) + ","
                    + "\"objectName\":" + jsonString(objectName) + ","
                    + "\"sourceFile\":" + jsonString(uploadFilePath.toString()) + ","
                    + "\"etag\":" + jsonString(uploadResponse.getETag()) + ","
                    + "\"opcRequestId\":" + jsonString(uploadResponse.getOpcRequestId())
                    + "}";
            sendJsonResponse(exchange, 200, responseJson);
        } catch (Exception e) {
            sendExceptionResponse(exchange, e);
        } finally {
            closeClient(client);
        }
    }

    private static void handleDownloadRequest(HttpExchange exchange) throws IOException {
        System.out.println("HTTP request: " + exchange.getRequestMethod() + " " + exchange.getRequestURI());
        if (!"GET".equalsIgnoreCase(exchange.getRequestMethod())) {
            sendMethodNotAllowed(exchange, "GET");
            return;
        }

        ObjectStorageClient client = null;
        try {
            Map<String, String> queryParameters = parseQueryParameters(exchange.getRequestURI().getRawQuery());
            String objectName = validateObjectName(requiredQueryParameter(queryParameters, "objectName"));
            Path downloadFilePath = Paths.get(requiredQueryParameter(queryParameters, "downloadPath")).toAbsolutePath().normalize();

            client = createObjectStorageClient();
            String namespaceName = getObjectStorageNamespace(client);
            GetObjectResponse downloadResponse = downloadObject(client, namespaceName, objectName, downloadFilePath);

            String responseJson = "{"
                    + "\"message\":\"Download completed successfully\","
                    + "\"bucket\":" + jsonString(BUCKET_NAME) + ","
                    + "\"namespace\":" + jsonString(namespaceName) + ","
                    + "\"objectName\":" + jsonString(objectName) + ","
                    + "\"destinationFile\":" + jsonString(downloadFilePath.toString()) + ","
                    + "\"contentLength\":" + jsonNumber(downloadResponse.getContentLength()) + ","
                    + "\"etag\":" + jsonString(downloadResponse.getETag()) + ","
                    + "\"opcRequestId\":" + jsonString(downloadResponse.getOpcRequestId())
                    + "}";
            sendJsonResponse(exchange, 200, responseJson);
        } catch (Exception e) {
            sendExceptionResponse(exchange, e);
        } finally {
            closeClient(client);
        }
    }

    /**
     * Creates an ObjectStorageClient using ${user.home}/.oci/config and the DEFAULT profile.
     */
    public static ObjectStorageClient createObjectStorageClient() throws IOException {
        Path configFilePath = Paths.get(System.getProperty("user.home"), ".oci", "config").toAbsolutePath().normalize();
        System.out.println("Creating OCI ObjectStorageClient using profile " + OCI_PROFILE + " from " + configFilePath);

        ConfigFile configFile = ConfigFileReader.parse(configFilePath.toString(), OCI_PROFILE);
        ConfigFileAuthenticationDetailsProvider authenticationProvider = new ConfigFileAuthenticationDetailsProvider(configFile);
        ObjectStorageClient client = ObjectStorageClient.builder().build(authenticationProvider);

        if (authenticationProvider.getRegion() != null) {
            client.setRegion(authenticationProvider.getRegion());
            System.out.println("OCI region loaded from config profile: " + authenticationProvider.getRegion().getRegionId());
        } else {
            System.out.println("No region found in the OCI config profile. The SDK will use its default endpoint resolution.");
        }

        System.out.println("OCI ObjectStorageClient created successfully.");
        return client;
    }

    /**
     * Retrieves the namespace instead of requiring it to be configured or hardcoded.
     */
    public static String getObjectStorageNamespace(ObjectStorageClient client) {
        System.out.println("Retrieving Object Storage namespace automatically.");
        GetNamespaceResponse response = client.getNamespace(GetNamespaceRequest.builder().build());
        String namespaceName = response.getValue();
        System.out.println("Object Storage namespace: " + namespaceName);
        return namespaceName;
    }

    /**
     * Lists every object in the bucket and prints the object name, size, and ETag.
     */
    public static String listAllObjects(ObjectStorageClient client, String namespaceName) {
        System.out.println("Listing objects in bucket " + BUCKET_NAME + ".");

        String start = null;
        int totalObjects = 0;
        boolean firstJsonObject = true;
        StringBuilder objectsJson = new StringBuilder();

        do {
            ListObjectsRequest request = ListObjectsRequest.builder()
                    .namespaceName(namespaceName)
                    .bucketName(BUCKET_NAME)
                    .fields(OBJECT_LIST_FIELDS)
                    .start(start)
                    .build();

            ListObjectsResponse response = client.listObjects(request);
            ListObjects listObjects = response.getListObjects();
            List<ObjectSummary> objects = listObjects.getObjects();

            if (objects != null) {
                for (ObjectSummary object : objects) {
                    totalObjects++;
                    System.out.println("Object name: " + valueOrUnavailable(object.getName()));
                    System.out.println("Size: " + valueOrUnavailable(object.getSize()));
                    System.out.println("ETag: " + valueOrUnavailable(object.getEtag()));
                    System.out.println();

                    if (!firstJsonObject) {
                        objectsJson.append(',');
                    }
                    objectsJson.append('{')
                            .append("\"name\":").append(jsonString(object.getName())).append(',')
                            .append("\"size\":").append(jsonNumber(object.getSize())).append(',')
                            .append("\"etag\":").append(jsonString(object.getEtag()))
                            .append('}');
                    firstJsonObject = false;
                }
            }

            start = listObjects.getNextStartWith();
        } while (start != null);

        if (totalObjects == 0) {
            System.out.println("No objects found in bucket " + BUCKET_NAME + ".");
        } else {
            System.out.println("Listed " + totalObjects + " object(s) from bucket " + BUCKET_NAME + ".");
        }

        return "{"
                + "\"bucket\":" + jsonString(BUCKET_NAME) + ","
                + "\"namespace\":" + jsonString(namespaceName) + ","
                + "\"count\":" + totalObjects + ","
                + "\"objects\":[" + objectsJson + "]"
                + "}";
    }

    /**
     * Uploads one local file to the bucket using a caller-supplied Object Storage object name.
     */
    public static PutObjectResponse uploadFile(ObjectStorageClient client, String namespaceName, Path localFilePath, String objectName) throws IOException {
        long contentLength = Files.size(localFilePath);
        String contentType = Files.probeContentType(localFilePath);
        if (contentType == null || contentType.isBlank()) {
            contentType = "application/octet-stream";
        }

        System.out.println("Uploading local file to Object Storage.");
        System.out.println("Source file: " + localFilePath);
        System.out.println("Target object: " + objectName);
        System.out.println("Content length: " + contentLength + " bytes");
        System.out.println("Content type: " + contentType);

        try (InputStream inputStream = Files.newInputStream(localFilePath)) {
            PutObjectRequest request = PutObjectRequest.builder()
                    .namespaceName(namespaceName)
                    .bucketName(BUCKET_NAME)
                    .objectName(objectName)
                    .contentLength(contentLength)
                    .contentType(contentType)
                    .putObjectBody(inputStream)
                    .build();

            PutObjectResponse response = client.putObject(request);
            System.out.println("Upload completed successfully.");
            System.out.println("Uploaded object ETag: " + valueOrUnavailable(response.getETag()));
            System.out.println("Upload OPC request ID: " + valueOrUnavailable(response.getOpcRequestId()));
            return response;
        }
    }

    /**
     * Downloads one existing object from the bucket to a caller-supplied local destination path.
     */
    public static GetObjectResponse downloadObject(ObjectStorageClient client, String namespaceName, String objectName, Path destinationFilePath) throws IOException {
        System.out.println("Downloading object from Object Storage.");
        System.out.println("Source object: " + objectName);
        System.out.println("Destination file: " + destinationFilePath);

        Path parent = destinationFilePath.getParent();
        if (parent != null) {
            Files.createDirectories(parent);
        }

        GetObjectRequest request = GetObjectRequest.builder()
                .namespaceName(namespaceName)
                .bucketName(BUCKET_NAME)
                .objectName(objectName)
                .build();

        GetObjectResponse response = client.getObject(request);
        InputStream responseStream = response.getInputStream();
        if (responseStream == null) {
            throw new IOException("OCI returned no content stream for object: " + objectName);
        }

        try (InputStream inputStream = responseStream) {
            Files.copy(inputStream, destinationFilePath, StandardCopyOption.REPLACE_EXISTING);
        }

        System.out.println("Download completed successfully.");
        System.out.println("Downloaded content length: " + valueOrUnavailable(response.getContentLength()) + " bytes");
        System.out.println("Downloaded object ETag: " + valueOrUnavailable(response.getETag()));
        System.out.println("Download OPC request ID: " + valueOrUnavailable(response.getOpcRequestId()));
        return response;
    }

    private static Map<String, String> parseQueryParameters(String rawQuery) {
        Map<String, String> queryParameters = new LinkedHashMap<>();
        if (rawQuery == null || rawQuery.isBlank()) {
            return queryParameters;
        }

        String[] pairs = rawQuery.split("&");
        for (String pair : pairs) {
            int separatorIndex = pair.indexOf('=');
            String key = separatorIndex >= 0 ? pair.substring(0, separatorIndex) : pair;
            String value = separatorIndex >= 0 ? pair.substring(separatorIndex + 1) : "";
            queryParameters.put(urlDecode(key), urlDecode(value));
        }

        return queryParameters;
    }

    private static String requiredQueryParameter(Map<String, String> queryParameters, String parameterName) {
        String value = queryParameters.get(parameterName);
        if (value == null || value.isBlank()) {
            throw new IllegalArgumentException("Missing required query parameter: " + parameterName);
        }
        return value;
    }

    private static String urlDecode(String value) {
        return URLDecoder.decode(value, StandardCharsets.UTF_8);
    }

    private static void closeClient(ObjectStorageClient client) {
        if (client != null) {
            System.out.println("Closing OCI ObjectStorageClient.");
            client.close();
        }
    }

    private static void sendMethodNotAllowed(HttpExchange exchange, String allowedMethod) throws IOException {
        exchange.getResponseHeaders().set("Allow", allowedMethod);
        sendJsonResponse(exchange, 405, "{\"error\":\"Method not allowed\",\"allowedMethod\":" + jsonString(allowedMethod) + "}");
    }

    private static void sendExceptionResponse(HttpExchange exchange, Exception exception) throws IOException {
        exception.printStackTrace(System.err);

        int statusCode = 500;
        String errorType = exception.getClass().getSimpleName();
        String serviceCode = null;
        String opcRequestId = null;

        if (exception instanceof IllegalArgumentException) {
            statusCode = 400;
        } else if (exception instanceof BmcException) {
            BmcException bmcException = (BmcException) exception;
            statusCode = bmcException.getStatusCode() > 0 ? bmcException.getStatusCode() : 500;
            serviceCode = bmcException.getServiceCode();
            opcRequestId = bmcException.getOpcRequestId();
        }

        String responseJson = "{"
                + "\"error\":" + jsonString(errorType) + ","
                + "\"message\":" + jsonString(exception.getMessage()) + ","
                + "\"serviceCode\":" + jsonString(serviceCode) + ","
                + "\"opcRequestId\":" + jsonString(opcRequestId)
                + "}";
        sendJsonResponse(exchange, statusCode, responseJson);
    }

    private static void sendJsonResponse(HttpExchange exchange, int statusCode, String responseJson) throws IOException {
        byte[] responseBytes = responseJson.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        exchange.sendResponseHeaders(statusCode, responseBytes.length);
        try (OutputStream responseBody = exchange.getResponseBody()) {
            responseBody.write(responseBytes);
        }
    }

    private static Path validateUploadFilePath(String filePath) {
        Path path = Paths.get(filePath).toAbsolutePath().normalize();
        if (!Files.isRegularFile(path)) {
            throw new IllegalArgumentException("Upload file does not exist or is not a regular file: " + path);
        }
        if (!Files.isReadable(path)) {
            throw new IllegalArgumentException("Upload file is not readable: " + path);
        }
        return path;
    }

    private static String validateObjectName(String objectName) {
        if (objectName == null || objectName.isBlank()) {
            throw new IllegalArgumentException("Object name must not be blank.");
        }
        return objectName;
    }

    private static String valueOrUnavailable(Object value) {
        return value == null ? "unavailable" : value.toString();
    }

    private static String jsonString(Object value) {
        if (value == null) {
            return "null";
        }
        return "\"" + escapeJson(value.toString()) + "\"";
    }

    private static String jsonNumber(Number value) {
        return value == null ? "null" : value.toString();
    }

    private static String escapeJson(String value) {
        StringBuilder escaped = new StringBuilder();
        for (int i = 0; i < value.length(); i++) {
            char character = value.charAt(i);
            switch (character) {
                case '\\':
                    escaped.append("\\\\");
                    break;
                case '"':
                    escaped.append("\\\"");
                    break;
                case '\b':
                    escaped.append("\\b");
                    break;
                case '\f':
                    escaped.append("\\f");
                    break;
                case '\n':
                    escaped.append("\\n");
                    break;
                case '\r':
                    escaped.append("\\r");
                    break;
                case '\t':
                    escaped.append("\\t");
                    break;
                default:
                    if (character < 0x20) {
                        escaped.append(String.format("\\u%04x", (int) character));
                    } else {
                        escaped.append(character);
                    }
                    break;
            }
        }
        return escaped.toString();
    }

    private static void printUsage() {
        System.out.println("Usage:");
        System.out.println("  java -jar target/oci-object-storage-single-file-app-1.0.0.jar");
        System.out.println("  java -jar target/oci-object-storage-single-file-app-1.0.0.jar <upload-file-path> <download-file-path> [upload-object-name] [download-object-name]");
        System.out.println();
        System.out.println("No arguments:");
        System.out.println("  Starts the HTTP server for Postman testing on http://127.0.0.1:8080.");
        System.out.println();
        System.out.println("Arguments:");
        System.out.println("  <upload-file-path>     Local file to upload.");
        System.out.println("  <download-file-path>   Local destination path for the downloaded object.");
        System.out.println("  [upload-object-name]   Optional object name. Defaults to the upload file name.");
        System.out.println("  [download-object-name] Optional object name to download. Defaults to the uploaded object name.");
    }
}
