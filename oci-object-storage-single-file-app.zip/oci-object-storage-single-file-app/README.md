# OCI Object Storage Single File App

## Project Overview

This is a Java 17 Maven application that uses the Oracle Cloud Infrastructure (OCI) Java SDK to interact with OCI Object Storage.

It is not Spring Boot and it is not a Spring REST API. The complete implementation is in one Java class only: `ObjectStorageApplication`.

The app supports two modes:

1. HTTP server mode for Postman testing.
2. Command-line mode for direct terminal testing.

The application uses the standard OCI SDK config file at `${user.home}/.oci/config`, loads the `DEFAULT` profile, automatically retrieves the Object Storage namespace, and uses this bucket:

```text
litedesk-oci-bucket
```

## Prerequisites

Install and configure:

1. Java Development Kit 17 or later.
2. Maven or the included Maven Wrapper.
3. OCI user API key authentication.
4. Access to the bucket `litedesk-oci-bucket`.
5. IAM permissions to list, upload, and download Object Storage objects.

Minimum IAM policy example:

```text
Allow group <group-name> to read buckets in compartment <compartment-name>
Allow group <group-name> to manage objects in compartment <compartment-name> where target.bucket.name = 'litedesk-oci-bucket'
```

## OCI Config File And PEM Key

The app reads OCI credentials from:

```text
${user.home}/.oci/config
```

On Windows for this user, that usually means:

```text
C:\Users\aljol\.oci\config
```

The file must contain a `DEFAULT` profile:

```ini
[DEFAULT]
user=ocid1.user.oc1..<your-user-ocid>
fingerprint=<your-api-key-fingerprint>
tenancy=ocid1.tenancy.oc1..<your-tenancy-ocid>
region=<your-oci-region>
key_file=C:\Users\aljol\.oci\oci_api_key.pem
```

Generate a private and public key if needed:

```bash
openssl genrsa -out ~/.oci/oci_api_key.pem 2048
openssl rsa -pubout -in ~/.oci/oci_api_key.pem -out ~/.oci/oci_api_key_public.pem
chmod 600 ~/.oci/oci_api_key.pem
```

Upload the public key to your OCI user under **User Settings > API Keys** and copy the fingerprint into the config file.

Do not put the private PEM key or OCI config file inside this project.

## Build With Maven

On Windows PowerShell, use the Maven Wrapper:

```powershell
.\mvnw.cmd clean package
```

If Maven is installed globally, you can also run:

```bash
mvn clean package
```

The executable JAR is created here:

```text
target\oci-object-storage-single-file-app-1.0.0.jar
```

## Run HTTP Server For Postman

Start the app with no arguments:

```powershell
java -jar target\oci-object-storage-single-file-app-1.0.0.jar
```

If port `8080` is already in use, start it on another port:

```powershell
java -Dserver.port=8081 -jar target\oci-object-storage-single-file-app-1.0.0.jar
```

Expected console output:

```text
HTTP server started successfully.
Postman base URL: http://127.0.0.1:8080
GET  http://127.0.0.1:8080/health
GET  http://127.0.0.1:8080/objects
POST http://127.0.0.1:8080/upload?filePath=C%3A%5CTemp%5Coci-upload-test.txt&objectName=oci-upload-test.txt
GET  http://127.0.0.1:8080/download?objectName=oci-upload-test.txt&downloadPath=C%3A%5CTemp%5Coci-download-test.txt
```

Keep this terminal window open while testing in Postman.

## Postman Test Steps

Create a local test file first:

```powershell
New-Item -ItemType Directory -Force C:\Temp
Set-Content -Path C:\Temp\oci-upload-test.txt -Value "Hello OCI Object Storage"
```

Test health:

```text
GET http://127.0.0.1:8080/health
```

Expected response:

```json
{"status":"UP","bucket":"litedesk-oci-bucket"}
```

List objects:

```text
GET http://127.0.0.1:8080/objects
```

Expected response shape:

```json
{"bucket":"litedesk-oci-bucket","namespace":"<namespace>","count":1,"objects":[{"name":"file.txt","size":123,"etag":"<etag>"}]}
```

Upload a local file from the machine running the Java app:

```text
POST http://127.0.0.1:8080/upload?filePath=C%3A%5CTemp%5Coci-upload-test.txt&objectName=oci-upload-test.txt
```

In Postman, the easier option is to use the **Params** tab:

```text
filePath     C:\Temp\oci-upload-test.txt
objectName   oci-upload-test.txt
```

Download an object to the machine running the Java app:

```text
GET http://127.0.0.1:8080/download?objectName=oci-upload-test.txt&downloadPath=C%3A%5CTemp%5Coci-download-test.txt
```

In Postman, use the **Params** tab:

```text
objectName     oci-upload-test.txt
downloadPath   C:\Temp\oci-download-test.txt
```

Verify the downloaded file:

```powershell
Get-Content C:\Temp\oci-download-test.txt
```

Expected file content:

```text
Hello OCI Object Storage
```

Important: the `filePath` and `downloadPath` are paths on the computer where the Java JAR is running, not paths on your Postman client if Postman is on a different machine.

## Command-Line Mode

You can still run the original operation sequence directly from the terminal:

```powershell
java -jar target\oci-object-storage-single-file-app-1.0.0.jar C:\Temp\oci-upload-test.txt C:\Temp\oci-download-test.txt
```

With two arguments, the uploaded object name defaults to the upload file name and the app downloads that same object.

You can provide explicit object names:

```powershell
java -jar target\oci-object-storage-single-file-app-1.0.0.jar C:\Temp\oci-upload-test.txt C:\Temp\oci-download-test.txt folder/upload.txt folder/existing-object.txt
```

## Copy The JAR To OCI Compute

Build locally:

```powershell
.\mvnw.cmd clean package
```

Copy the JAR to an OCI Compute instance:

```bash
scp target/oci-object-storage-single-file-app-1.0.0.jar opc@<compute-public-ip>:/home/opc/
```

Copy OCI config and PEM key if needed:

```bash
scp -r ~/.oci opc@<compute-public-ip>:/home/opc/.oci
```

Protect the key on the compute instance:

```bash
chmod 700 /home/opc/.oci
chmod 600 /home/opc/.oci/*.pem
```

## Run The JAR On OCI Compute

Run command-line mode on the instance:

```bash
java -jar /home/opc/oci-object-storage-single-file-app-1.0.0.jar /home/opc/upload.txt /home/opc/downloaded.txt
```

HTTP mode binds to `127.0.0.1:8080` for safer local testing. To test the compute instance HTTP server from your laptop with Postman, use an SSH tunnel:

```bash
ssh -L 8080:localhost:8080 opc@<compute-public-ip>
```

Then run this on the compute instance in the SSH session:

```bash
java -jar /home/opc/oci-object-storage-single-file-app-1.0.0.jar
```

Postman on your laptop can then call:

```text
http://127.0.0.1:8080/health
```

## Expected Console Output

HTTP mode logs each request:

```text
HTTP request: GET /health
HTTP request: GET /objects
Creating OCI ObjectStorageClient using profile DEFAULT from C:\Users\aljol\.oci\config
Retrieving Object Storage namespace automatically.
Listing objects in bucket litedesk-oci-bucket.
Closing OCI ObjectStorageClient.
```

Command-line mode logs the full sequence:

```text
Starting OCI Object Storage application.
Listing objects in bucket litedesk-oci-bucket.
Uploading local file to Object Storage.
Upload completed successfully.
Listing objects in bucket litedesk-oci-bucket.
Downloading object from Object Storage.
Download completed successfully.
All OCI Object Storage operations completed successfully.
Closing OCI ObjectStorageClient.
```

## Troubleshooting

`Port 8080 already in use`

Stop the other process using port `8080`, or start this app on another port with `java -Dserver.port=8081 -jar target\oci-object-storage-single-file-app-1.0.0.jar`.

`404 Not Found` in Postman

Use one of the exact paths: `/health`, `/objects`, `/upload`, or `/download`.

`405 Method Not Allowed`

Use `GET` for `/health`, `GET` for `/objects`, `POST` for `/upload`, and `GET` for `/download`.

`Missing required query parameter`

Check that `filePath`, `objectName`, or `downloadPath` is present in the Postman Params tab.

`Upload file does not exist`

The `filePath` must exist on the machine running the Java app.

`401 NotAuthenticated`

Check user OCID, tenancy OCID, fingerprint, private PEM key path, private key contents, and system clock.

`403 NotAuthorizedOrNotFound`

Check IAM policies and bucket permissions for `litedesk-oci-bucket`.

`404 BucketNotFound`

Check that `litedesk-oci-bucket` exists in the region configured in the `DEFAULT` profile.

`404 ObjectNotFound`

Check the `objectName`. Object names are case-sensitive.

`java.lang.UnsupportedClassVersionError`

Run with Java 17 or later.

## Security Notes

Do not hardcode credentials, OCIDs, namespaces, regions, or local file paths in source code.

Do not commit `${user.home}/.oci/config` or PEM key files to source control.

Protect private keys with restrictive permissions.

Grant only the IAM permissions required for this bucket and these operations.

HTTP mode binds to `127.0.0.1` only. Do not expose this local testing server directly to the public internet.
